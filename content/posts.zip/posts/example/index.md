---
title: "Esempio"
# date: 2023-06-11T13:05:09+02:00
image: "image.jpeg"
draft: true
external_url: 
# categories:
#    - test
tags:
   - prodotto 📦
   - consulenza 💡
   - incubatore 🐣
   - community 🌎
   - startup  🚀
   - co-working 🖥️
   - formazione 🎓
   - eventi 🎉
---

