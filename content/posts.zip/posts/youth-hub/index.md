---
title: "Youth Hub"
# date: 2023-06-11T13:05:09+02:00
image: "image.jpeg"
draft: false
external_url: https://www.youthhub.it/
# categories:
#    - test
tags:
   - eventi 🎉
   - community 🌎
---

Youth Hub Catania è un’associazione no-profit che si occupa di promuovere lo spirito imprenditoriale tra gli studenti e gli aspiranti startupper. L’associazione organizza eventi, workshop, hackathon e altre iniziative per favorire la creazione di una rete di contatti e di opportunità nel settore dell’innovazione.

Scopri di più sul sito di [YouthHub](https://www.youthhub.it)!